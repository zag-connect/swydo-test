# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [0.2.2](https://github.com/Swydo/star-wars-integration/compare/0.2.1...0.2.2) (2020-01-07)



### [0.2.1](https://github.com/Swydo/star-wars-integration/compare/0.2.0...0.2.1) (2019-10-16)



## [0.2.0](https://github.com/Swydo/star-wars-integration/compare/0.1.11...0.2.0) (2019-09-13)


### Features

* set endpoint name ([#7](https://github.com/Swydo/star-wars-integration/issues/7)) ([639ce51](https://github.com/Swydo/star-wars-integration/commit/639ce51))



### [0.1.11](https://github.com/Swydo/star-wars-integration/compare/0.1.10...0.1.11) (2019-09-10)



### [0.1.10](https://github.com/Swydo/star-wars-integration/compare/0.1.9...0.1.10) (2019-09-10)



### [0.1.9](https://github.com/Swydo/star-wars-integration/compare/0.1.8...0.1.9) (2019-09-03)



### [0.1.8](https://github.com/Swydo/star-wars-integration/compare/0.1.7...0.1.8) (2019-08-27)



### [0.1.7](https://github.com/Swydo/star-wars-integration/compare/0.1.6...0.1.7) (2019-08-08)



### [0.1.6](https://github.com/Swydo/star-wars-integration/compare/0.1.5...0.1.6) (2019-08-08)



### [0.1.5](https://github.com/Swydo/star-wars-integration/compare/0.1.4...0.1.5) (2019-08-07)



### [0.1.4](https://github.com/Swydo/star-wars-integration/compare/0.1.3...0.1.4) (2019-08-05)



### [0.1.3](https://github.com/Swydo/star-wars-integration/compare/0.1.2...0.1.3) (2019-08-02)



### [0.1.2](https://github.com/Swydo/star-wars-integration/compare/0.1.1...0.1.2) (2019-07-17)



### [0.1.1](https://github.com/Swydo/star-wars-integration/compare/0.1.0...0.1.1) (2019-06-26)



## 0.1.0 (2019-06-24)


### Features

* add swapi integration ([900724d](https://github.com/Swydo/star-wars-integration/commit/900724d))
